


<?php
// Kết nối tới cơ sở dữ liệu
$servername = "localhost"; // Thay thế bằng thông tin của bạn
$username = "root";
$password = ""; // Nếu bạn dùng MAMP hoặc XAMPP có thể để trống
$dbname = "daao";

// CREATE DATABASE daao;

// USE contact_db;

// CREATE TABLE contacts (
//     id INT(11) AUTO_INCREMENT PRIMARY KEY,
//     name VARCHAR(100) NOT NULL,
//     email VARCHAR(100) NOT NULL,
//     message TEXT NOT NULL,
//     submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
// );

$conn = new mysqli($servername, $username, $password, $dbname);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

// Nhận dữ liệu từ form
$name = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['message'];

// Chuẩn bị và chạy câu lệnh SQL
$stmt = $conn->prepare("INSERT INTO contacts (name, email, message) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $name, $email, $message);

if ($stmt->execute()) {
    echo "Liên hệ của bạn đã được gửi thành công!";
    // Gửi mail tự động trả lời
    $to = $email;
    $subject = "Cảm ơn bạn đã liên hệ";
    $body = "Chào $name,\n\nCảm ơn bạn đã liên hệ với chúng tôi. Chúng tôi sẽ sớm phản hồi lại bạn.\n\nTrân trọng!";
    $headers = "From: nhutnguyenmc2022@gmail.com";

    mail($to, $subject, $body, $headers);
} else {
    echo "Có lỗi xảy ra khi gửi liên hệ của bạn. Vui lòng thử lại.";
}

// Đóng kết nối
$stmt->close();
$conn->close();
?>



